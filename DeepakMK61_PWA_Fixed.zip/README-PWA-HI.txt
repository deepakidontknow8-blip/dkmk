Deepak.mk61 PWA - Hindi setup

Files:
- index.html: your original app with manifest link and service worker registration fixed
- manifest.json: standalone web app manifest
- service-worker.js: caches the app shell and same-origin GET resources
- icon-192.png / icon-512.png: app icons

IMPORTANT:
1. Keep all five files in the same folder.
2. Upload the folder contents to an HTTPS host (for example GitHub Pages or Netlify). PWA/service workers do not work from a file:// URL; localhost is okay for testing.
3. Open the HTTPS URL once while online, then wait for the page to finish loading.
4. In Chrome, use menu > Install app / Add to Home screen.
5. Test offline after the first successful online load. External Unsplash images, Google Maps, and Google Translate text-to-speech still require internet.

This fixes the two PWA Builder action items related to manifest and service worker. It does not compile an Android APK by itself; use the hosted HTTPS URL in PWA Builder after deployment.
